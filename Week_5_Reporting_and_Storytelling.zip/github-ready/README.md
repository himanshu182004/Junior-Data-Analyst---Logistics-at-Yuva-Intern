# Week 5 — Reporting and Storytelling with Data

Logistics Operations Analytics case study using public World Bank logistics data.

Key evidence:
- India LPI rank: 54 (2014), 44 (2018), 38 (2023)
- India LPI score: 3.08 (2014), 3.18 (2018), 3.4 (2023)
- 2023 dimensions: Customs 3.0, Infrastructure 3.2, International shipments 3.5,
  Logistics competence 3.5, Timeliness 3.6, Tracking & tracing 3.4
- Import-release time comparisons: 2021–2023

Sources:
https://lpi.worldbank.org/
https://lpi.worldbank.org/sites/default/files/2023-04/LPI_2023_report_with_layout.pdf

Do not upload confidential company data, credentials or personal data.
